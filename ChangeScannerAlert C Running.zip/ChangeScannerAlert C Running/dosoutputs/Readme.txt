DOSOutputs

This class capture the outpus of a DOS command line via API functions, redirecting the 
stdOutput pipe and the stdErr pipe of a DOS application from the screen to the pipe
that this class create.

Marco Pipino
marcopipino@libero.it
28/02/2002

PS: It not work correctly with 16-bit application on Windows 95